package com.example.quizappbycouchbase

data class ImageObject(val unique_id: Int, val name: String, val imagevect_l2: List<Double>,val category: String)
