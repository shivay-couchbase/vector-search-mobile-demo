package com.example.quizappbycouchbase

class Models {
}