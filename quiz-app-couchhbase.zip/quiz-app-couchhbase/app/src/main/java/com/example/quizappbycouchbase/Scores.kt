package com.example.quizappbycouchbase

data class Scores (
    val username: String,
    val score: Int,
    val category: String
)